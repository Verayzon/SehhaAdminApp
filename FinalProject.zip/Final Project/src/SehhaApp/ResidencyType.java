package SehhaApp;

/**
 * resdidency type of the patient
 * @author Josh, Marcus, Rami, Meteb
 * created 5/3/2023
 * @version 5/19/2023
 *
 */
public enum ResidencyType {
	VISITOR, RESIDENT;
}
